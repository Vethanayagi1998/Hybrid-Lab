package com.example.cityguide;

import androidx.appcompat.app.AppCompatActivity;
import com.example.cityguide.R;

import android.os.Bundle;

public class BangalorePalace_feat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bangalore_palace);
    }
}