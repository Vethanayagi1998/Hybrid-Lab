package com.example.cityguide.Common;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.cityguide.R;

public class Wonderla_feat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wonderla);
    }
}